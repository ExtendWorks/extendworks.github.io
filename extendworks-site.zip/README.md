# ExtendWorks — extension pages

Static site for GitHub Pages (repo `extendworks.github.io`). Text Replacer opens `https://extendworks.github.io/text-replacer/welcome/` once, right after install.

- `text-replacer/welcome/index.html` — two modes in one page: "pin" (how to pin the extension) and "usage" (how to use it).
- `text-replacer/welcome/app.js` — asks the extension every 1.5 s whether its icon is on the toolbar (`getPinState`) and switches the mode. Manual links always win.
- `text-replacer/welcome/img/` — illustrations.

After the item is created in the Chrome Web Store, set `STORE_EXTENSION_ID` in `text-replacer/welcome/app.js`.
The extension must list this site in `externally_connectable.matches` in `manifest.json`.
